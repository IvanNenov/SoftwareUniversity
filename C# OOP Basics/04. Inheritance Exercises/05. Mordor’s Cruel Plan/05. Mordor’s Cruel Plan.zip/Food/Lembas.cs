﻿using System;
using System.Collections.Generic;
using System.Text;

public class Lembas : Food
{
    public Lembas()
    {
        this.Happiness = 3;
    }
}
