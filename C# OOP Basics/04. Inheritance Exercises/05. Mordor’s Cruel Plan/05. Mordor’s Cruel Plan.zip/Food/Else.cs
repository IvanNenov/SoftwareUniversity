﻿using System;
using System.Collections.Generic;
using System.Text;

public class Else : Food
{
    public Else()
    {
        this.Happiness = -1;
    }
}
