﻿using System;
using System.Collections.Generic;
using System.Text;

public class HoneyCake : Food
{
    public HoneyCake()
    {
        this.Happiness = 5;
    }
}
