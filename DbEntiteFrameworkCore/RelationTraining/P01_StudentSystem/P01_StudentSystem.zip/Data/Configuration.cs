﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    internal class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-GG1QI3R\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
