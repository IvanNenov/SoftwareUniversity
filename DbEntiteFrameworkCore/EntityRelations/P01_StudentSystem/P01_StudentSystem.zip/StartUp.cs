﻿ using System;

namespace P01_StudentSystem
{
    class StartUp
    {
        static void Main(string[] args)
        {
                
        }
    }
}
