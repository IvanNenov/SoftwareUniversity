﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    class Configuration
    {
        internal static string ConnectionString => @"Server=DESKTOP-GG1QI3R\SQLEXPRESS;Database=FootballBetting;Integrated Security = True;";
    }
}
