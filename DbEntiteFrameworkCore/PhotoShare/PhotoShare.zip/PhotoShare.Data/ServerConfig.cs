﻿namespace PhotoShare.Data
{
    internal class ServerConfig
    {
        internal static string ConnectionString => @"Server=DESKTOP-GG1QI3R\SQLEXPRESS;Database=PhotoShare;Integrated Security=True;";
    }
}
