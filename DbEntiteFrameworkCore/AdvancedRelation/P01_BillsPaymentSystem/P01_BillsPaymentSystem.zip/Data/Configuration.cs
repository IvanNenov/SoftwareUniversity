﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_BillsPaymentSystem.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-GG1QI3R\SQLEXPRESS;Database=BillsPaymentSystem;Integrated Security=true;";
    }
}
