﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Employees.Data
{
    internal class Configuration
    { 
        public const string Connectionstring = @"Server=DESKTOP-GG1QI3R\SQLEXPRESS;Database=EmployeesDb;Integrated Security=True;";
    }
}
