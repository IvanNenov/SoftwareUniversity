﻿using System;

using P02_DatabaseFirst.Data;

namespace P02_DatabaseFirst
{
    class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}
