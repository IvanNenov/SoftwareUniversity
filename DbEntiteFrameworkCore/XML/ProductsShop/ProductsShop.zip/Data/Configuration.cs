﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductsShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-GG1QI3R\SQLEXPRESS;Database=ProductShop;Integrated Security=true";
    }
}
