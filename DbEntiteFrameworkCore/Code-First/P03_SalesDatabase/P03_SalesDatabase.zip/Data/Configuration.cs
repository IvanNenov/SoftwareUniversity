﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-GG1QI3R\SQLEXPRESS;Database=Sales;Integrated Security=True;";
    }
}
