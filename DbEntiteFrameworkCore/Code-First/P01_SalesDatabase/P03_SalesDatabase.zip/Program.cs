﻿using System;

namespace P01_SalesDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
