﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_SalesDatabase.Data
{
    class Configuration
    {
        public const string Connection = @"Server=DESKTOP-GG1QI3R\SQLEXPRESS;Database=Sales;Integrated Security=True";
    }
}
