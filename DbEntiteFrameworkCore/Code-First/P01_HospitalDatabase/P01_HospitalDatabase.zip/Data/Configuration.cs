﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public static string Connection { get;set; } = @"Server=DESKTOP-GG1QI3R\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}
